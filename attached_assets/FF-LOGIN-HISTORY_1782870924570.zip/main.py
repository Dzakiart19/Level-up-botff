import os
import sys
import time
import json
import threading
import base64
import hashlib
import requests
import urllib3
import urllib.parse
from datetime import datetime
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

try:
    import MajoRLogin_pb2 as mLpB
    import MajorLoginRes_pb2 as mLrPb
except ImportError:
    print("\n[!] Error: Protobuf files (MajoRLogin_pb2.py, MajorLoginRes_pb2.py) not found!")
    sys.exit()

urllib3.disable_warnings()

AeSkEy = b'Yg&tc%DEuh6%Zc^8'
AeSiV  = b'6oyZDr22E3ychjM%'
MAJOR_LOGIN_URL = "https://loginbp.ggpolarbear.com/MajorLogin"
HISTORY_URL = "https://client.ind.freefiremobile.com/GetLoginHistory"

MAJOR_LOGIN_HEADERS = {
    "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 11; SM-S908E Build/TP1A.220624.014)",
    "Connection": "Keep-Alive",
    "Accept-Encoding": "gzip",
    "Content-Type": "application/octet-stream",
    "Expect": "100-continue",
    "X-GA": "v1 1",
    "X-Unity-Version": "2018.4.11f1",
    "ReleaseVersion": "OB54"
}

PLATFORM_MAP = {
    3: "Facebook",
    4: "Guest",
    5: "VK",
    6: "Huawei",
    8: "Google",
    11: "X (Twitter)",
    13: "AppleId",
}

C = "\033[1;36m"
G = "\033[1;32m"
R = "\033[1;31m"
Y = "\033[1;33m"
W = "\033[1;37m"
B = "\033[1m"
S = "\033[0m"

def clear():
    os.system('clear' if os.name == 'posix' else 'cls')

def draw_line():
    print(f"{C}══════════════════════════════════════════════════════{S}")

def banner():
    clear()
    ascii_art = f"""{C}
               ████████╗  ██╗  ██████╗ 
               ╚══██╔══╝ ███║ ██╔═══██╗
                  ██║    ╚██║ ██║   ██║
                  ██║     ██║ ██║   ██║
                  ██║     ██║ ╚██████╔╝
                  ╚═╝     ╚═╝  ╚═════╝{S}"""
    
    print(ascii_art) 
    draw_line()
    print(f"{W}{B}             FF LOGIN HISTORY EXTRACTOR{S}")
    draw_line()

def show_credits():
    draw_line()
    print(f"\n {C}[★] {W}Developer : {C}@spideyabd And @ROX_T10{S}")
    print(f" {C}[★] {W}Join      : {G}t.me/SPIDEYFREEFILES{S}")
    print(f" {C}[★] {W}Join      : {G}t.me/T10INDRAJIT{S}\n")

def enc(d):
    return AES.new(AeSkEy, AES.MODE_CBC, AeSiV).encrypt(pad(d, 16))

def dec(d):
    try:
        return unpad(AES.new(AeSkEy, AES.MODE_CBC, AeSiV).decrypt(d), 16)
    except:
        return d

def get_base_url(lock_region):
    lock_region = lock_region.upper()
    ind_regions = ["IND"]
    us_regions = ["BR", "US", "NA", "SAC"]
    if lock_region in ind_regions:
        return "https://client.ind.freefiremobile.com"
    elif lock_region in us_regions:
        return "https://client.us.freefiremobile.com"
    else:
        return "https://clientbp.ggpolarbear.com"

def build_majorlogin(tok, open_id, p_type):
    m = mLpB.MajorLogin()
    m.event_time = str(datetime.now())[:-7]
    m.game_name = "free fire"
    m.platform_id = p_type
    m.client_version = "1.120.1"
    m.system_software = "Android OS 9 / API-28"
    m.system_hardware = "Handheld"
    m.telecom_operator = "Verizon"
    m.network_type = "WIFI"
    m.screen_width = 1920
    m.screen_height = 1080
    m.screen_dpi = "280"
    m.processor_details = "ARM64 FP ASIMD AES VMH | 2865 | 4"
    m.memory = 3003
    m.gpu_renderer = "Adreno (TM) 640"
    m.gpu_version = "OpenGL ES 3.1 v1.46"
    m.unique_device_id = "Google|34a7dcdf-a7d5-4cb6-8d7e-3b0e448a0c57"
    m.client_ip = "223.191.51.89"
    m.language = "en"
    m.open_id = open_id
    m.open_id_type = str(p_type)
    m.device_type = "Handheld"
    m.access_token = tok
    m.platform_sdk_id = 1
    m.client_using_version = "7428b253defc164018c604a1ebbfebdf"
    m.login_by = 3
    m.channel_type = 3
    m.cpu_type = 2
    m.cpu_architecture = "64"
    m.client_version_code = "2019118695"
    m.login_open_id_type = p_type
    m.origin_platform_type = str(p_type)
    m.primary_platform_type = str(p_type)
    return enc(m.SerializeToString())

def read_varint(data, offset):
    res = 0
    shift = 0
    while True:
        if offset >= len(data):
            break
        b = data[offset]
        offset += 1
        res |= (b & 0x7f) << shift
        if not (b & 0x80):
            break
        shift += 7
    return res, offset

def parse_record(data):
    rec = {}
    offset = 0
    while offset < len(data):
        tag, offset = read_varint(data, offset)
        wt, f = tag & 7, tag >> 3
        if wt == 0:
            val, offset = read_varint(data, offset)
            if f == 1:
                rec['ts'] = val
            elif f == 2:
                rec['ram'] = val
        elif wt == 2:
            length, offset = read_varint(data, offset)
            val = data[offset:offset+length]
            offset += length
            if f == 3:
                rec['dev'] = val.decode(errors='ignore')
            elif f == 4:
                rec['arch'] = val.decode(errors='ignore')
        else:
            break
    return rec

def parse_history_protobuf(data):
    records = []
    offset = 0
    while offset < len(data):
        tag, offset = read_varint(data, offset)
        wt, f = tag & 7, tag >> 3
        if wt == 0:
            val, offset = read_varint(data, offset)
        elif wt == 2:
            length, offset = read_varint(data, offset)
            val = data[offset:offset+length]
            offset += length
            if f == 1:
                records.append(parse_record(val))
        else:
            break
    return records

def get_jwt_from_access(tok):
    oId = None
    try:
        r = requests.get(f"https://100067.connect.garena.com/oauth/token/inspect?token={tok}", headers={"User-Agent": "Mozilla/5.0"}, timeout=5).json()
        oId = r.get("open_id")
    except:
        pass

    if not oId:
        try:
            uid_headers = {"access-token": tok, "user-agent": "Mozilla/5.0 (Linux; Android 10; K) Chrome/124.0.0.0"}
            uid_res = requests.get("https://prod-api.reward.ff.garena.com/redemption/api/auth/inspect_token/", headers=uid_headers, verify=False, timeout=5).json()
            uid = uid_res.get("uid")
            if uid:
                openid_res = requests.post("https://topup.pk/api/auth/player_id_login", headers={"Content-Type": "application/json"}, json={"app_id": 100067, "login_id": str(uid)}, verify=False, timeout=5).json()
                oId = openid_res.get("open_id")
        except:
            pass

    if not oId:
        return None

    platforms = [8, 3, 4, 6]
    for p_type in platforms:
        pl = build_majorlogin(tok, oId, p_type)
        try:
            x = requests.post(MAJOR_LOGIN_URL, headers=MAJOR_LOGIN_HEADERS, data=pl, timeout=10, verify=False)
            if x.status_code == 200:
                res = mLrPb.MajorLoginRes()
                try:
                    res.ParseFromString(dec(x.content))
                except:
                    res.ParseFromString(x.content)
                if res.token:
                    return res.token
        except:
            continue
    return None

def decode_ff_name(b64_str):
    try:
        key = b"1e5898ccb8dfdd921f9bdea848768b64a201"
        b64_str = b64_str.strip()
        b64_str += "=" * ((4 - len(b64_str) % 4) % 4)
        encrypted_bytes = base64.b64decode(b64_str)
        decrypted_bytes = bytearray()
        for i, byte in enumerate(encrypted_bytes):
            key_byte = key[i % len(key)]
            decrypted_bytes.append(byte ^ key_byte)
        name = decrypted_bytes.decode('utf-8', errors='ignore')
        return name
    except Exception as e:
        return f"Error decoding: {str(e)}"

def get_player_info_str(jwt):
    try:
        payload_b64 = jwt.split('.')[1]
        payload_b64 += "=" * ((4 - len(payload_b64) % 4) % 4)
        decoded = json.loads(base64.urlsafe_b64decode(payload_b64).decode('utf-8'))
        raw_nickname = decoded.get("nickname", "Unknown")
        name = decode_ff_name(raw_nickname)
        uid = decoded.get("account_id", "Unknown")
        region = decoded.get("lock_region", "Unknown")
        p_id = decoded.get("external_type", 0)
        platform = PLATFORM_MAP.get(p_id, f"Unknown ({p_id})")
        base_url = get_base_url(region)
        output = f"\n{G}[✓] {B}{W}PLAYER INFORMATION{S}\n\n"
        output += f" {C}[◆] Account Name :{W} {name}{S}\n"
        output += f" {C}[◆] Account ID   :{W} {uid}{S}\n"
        output += f" {C}[◆] Platform     :{W} {platform}{S}\n"
        output += f" {C}[◆] Region       :{W} {region}{S}\n"
        return output, base_url, None
    except Exception as e:
        return "", "", f"Could not parse Player Info: {str(e)}"

def get_history_str(jwt, base_url):
    history_url = f"{base_url}/GetLoginHistory"
    history_headers = {
        "Expect": "100-continue",
        "Authorization": f"Bearer {jwt}",
        "X-Unity-Version": "2018.4.11f1",
        "X-GA": "v1 1",
        "ReleaseVersion": "OB54",
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)",
        "Host": base_url.replace("https://", ""),
        "Connection": "close",
        "Accept-Encoding": "gzip, deflate, br"
    }
    try:
        r = requests.post(history_url, headers=history_headers, data=enc(b""), timeout=15, verify=False)
        if r.status_code != 200:
            return "", f"History Request Failed: HTTP {r.status_code}"
        try:
            d = dec(r.content)
        except:
            d = r.content
        records = parse_history_protobuf(d)
        if not records:
            output = f"\n{G}[✓] {B}{W}LOGIN HISTORY{S}\n\n"
            output += f" {Y}[!]{W} No login history records found for this account.{S}\n"
            return output, None
        output = f"\n{G}[✓] {B}{W}LOGIN HISTORY{S}\n"
        for i, rec in enumerate(records, 1):
            ts_raw = rec.get('ts', 0)
            try:
                date_str = datetime.fromtimestamp(ts_raw).strftime('%Y-%m-%d %H:%M:%S')
            except:
                date_str = "Invalid Timestamp"
            dev = rec.get('dev', 'Unknown Device')
            arch = rec.get('arch', 'Unknown Architecture')
            ram = rec.get('ram', 0)
            output += f"\n {C}[◆] Record #{i}{S}\n"
            output += f"     {C}├─ Time        :{W} {date_str}{S}\n"
            output += f"     {C}├─ Device      :{W} {dev}{S}\n"
            output += f"     {C}├─ Architecture:{W} {arch}{S}\n"
            output += f"     {C}└─ Memory (RAM):{W} {ram} MB{S}\n"
        return output, None
    except Exception as e:
        return "", f"Connection or Decoding Error: {str(e)}"

def process_token_with_loader(raw_token):
    result_data = {"jwt": None, "player_output": "", "history_output": "", "error": None, "base_url": None}
    def worker():
        try:
            if raw_token.startswith("ey") and "." in raw_token:
                jwt = raw_token
            else:
                jwt = get_jwt_from_access(raw_token)
            if not jwt:
                result_data["error"] = "Failed to obtain JWT. Token invalid or expired."
                return
            result_data["jwt"] = jwt
            p_out, base_url, p_err = get_player_info_str(jwt)
            if p_err:
                result_data["error"] = p_err
                return
            result_data["player_output"] = p_out
            result_data["base_url"] = base_url
            h_out, h_err = get_history_str(jwt, base_url)
            if h_err:
                result_data["error"] = h_err
                return
            result_data["history_output"] = h_out
        except Exception as e:
            result_data["error"] = str(e)
    t = threading.Thread(target=worker)
    t.start()
    spinner = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
    print()
    spin_idx = 0
    while t.is_alive():
        spin = spinner[spin_idx % len(spinner)]
        sys.stdout.write(f"\r {C}[{spin}] {W}PROCESSING TOKEN...{S}")
        sys.stdout.flush()
        time.sleep(0.05)
        spin_idx += 1
    sys.stdout.write(f"\r {C}[✔] {W}PROCESSING COMPLETE!    {S}\n")
    sys.stdout.flush()
    print()
    return result_data

def main():
    os.system("")
    while True:
        banner()
        print(f"\n {W}[#] {C}Instruction:{W} Paste Access OR Game JWT Token.")
        print(f" {W}[#] {C}Command:{W} Type 'Q' to exit the application.\n")
        raw_token = input(f"{Y} [>] {W}Enter Token: {S}").strip()
        if raw_token.upper() in ('Q', 'EXIT'):
            break
        if not raw_token:
            print(f"\n{R}[!] Error: Empty input! Please enter a valid token.{S}\n")
            print(f"{C} [➔] Press[ENTER] to try again...{S}")
            input()
            continue
        res = process_token_with_loader(raw_token)
        if res["error"]:
            print(f"{R}[✗] {res['error']}{S}\n")
            show_credits()
            print(f"{C} [➔] Press [ENTER] to try again...{S}")
            input()
            continue
        banner()
        print(res["player_output"])
        print(res["history_output"])
        show_credits()
        print(f"{C} [➔] Search completed successfully.{S}")
        print(f"{W} [➔] Press[ENTER] to perform another lookup...{S}")
        input()
    clear()
    draw_line()
    print(f"\n{G} [★] Wishing you a wonderful journey ahead. Goodbye!{S}")
    print(f"{W}     Keep shining, stay strong, and be well until next time.{S}\n")
    draw_line()
    print()
    print(f"{C}═══════════════════ SESSION CLOSED ═══════════════════{S}\n")
    sys.exit()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{R} [!] Session interrupted by user.{S}")
        sys.exit()